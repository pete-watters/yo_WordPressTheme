<?php
/**
 * kontainers_WP_theme functions file
 *
 * @package WordPress
 * @subpackage kontainers_WP_theme
 * @since kontainers_WP_theme 1.0
 */


/******************************************************************************\
	Theme support, standard settings, menus and widgets
\******************************************************************************/

add_theme_support( 'post-formats', array( 'image', 'quote', 'status', 'link' ) );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );

/**
 * Print custom header styles
 * @return void
 */

register_nav_menu( 'main-menu', __( 'Primary menu', 'kontainers_wp_theme' ) );

/**
 * Include editor stylesheets
 * @return void
 */
function kontainers_wp_theme_editor_style() {
    add_editor_style( 'css/wp-editor-style.css' );
}
add_action( 'init', 'kontainers_wp_theme_editor_style' );


/******************************************************************************\
	Scripts and Styles
\******************************************************************************/

/**
 * Enqueue kontainers_wp_theme scripts
 * @return void
 */
function kontainers_wp_theme_enqueue_scripts() {
	wp_enqueue_style( 'kontainers_wp_theme-styles', get_stylesheet_uri(), array(), '1.0' );
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'default-scripts', get_template_directory_uri() . '/js/scripts.min.js', array(), '1.0', true );
	if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
}
add_action( 'wp_enqueue_scripts', 'kontainers_wp_theme_enqueue_scripts' );


/******************************************************************************\
	Content functions
\******************************************************************************/

/**
 * Displays meta information for a post
 * @return void
 */
function kontainers_wp_theme_post_meta() {
	if ( get_post_type() == 'post' ) {
		echo "<a href=\"#\"><span class=\"posted-on\">";
		echo sprintf(
			__( 'Posted on %s in %s%s. ', 'kontainers_wp_theme' ),
			get_the_time( get_option( 'date_format' ) ),
			get_the_category_list( ', ' ),
			get_the_tag_list( __( ', <b>Tags</b>: ', 'kontainers_wp_theme' ), ', ' ),
			get_the_author_link()
		);
		echo  "</span></a>";
	}
	edit_post_link( __( ' (edit)', 'kontainers_wp_theme' ), '<span class="edit-link">', '</span>' );
}


/**
 * Include editor stylesheets
 * @return void
 */
//TODO move functionality from top-nav and contact-us here to share global vars
//function kontainers_wp_theme_check_domain() {
//
//
//	global $phone_number;
//	global $contact_email;
//
//	/* Domain internationalisation */
//	$serverHost = $_SERVER['HTTP_HOST'] ;
//	if (fnmatch('*kontainers.co.uk', $serverHost)) {
//		// .co.uk domain
//		$phone_number = get_post_meta($post->ID, "kontainers_uk_email", true);
//		$contact_email = get_post_meta($post->ID, "kontainers_uk_phone", true);
//	} else {
//		// not .co.uk e.g. us
//		$phone_number = get_post_meta($post->ID, "kontainers_us_email", true);
//		$contact_email = get_post_meta($post->ID, "kontainers_us_phone", true);
//	}
//	//return [$phone_number, $contact_email];
//}
//add_action( 'init', 'kontainers_wp_theme_check_domain' );






/**
 * Add Google Analytics code
 */
	add_action('wp_footer', 'add_googleanalytics');
	function add_googleanalytics() {
?>

	<script type="text/javascript">
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-58749663-1']);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();

	</script>

<?php } ?>

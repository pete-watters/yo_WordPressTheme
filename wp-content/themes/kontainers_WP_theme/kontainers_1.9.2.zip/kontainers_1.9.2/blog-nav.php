<div class="blog-nav">
    <div class="row">
        <div class="four columns">
            <?php include('template-recentPosts-dropdown.php') ?>
        </div>
        <div class="four columns">
            <?php include('template-categories-dropdown.php') ?>
        </div>
        <div class="four columns">
            <?php get_search_form(); ?>
        </div>
    </div>
</div>
Thank you for using the "kontainers_WP_theme"" Wordpress Theme.

	i)
	ii)
	iv)

## Copyrights for Resources used in this theme.


	For any help you can mail us at support@northemes.com
(function($) {
	// jquery goodness
})(jQuery);
<?php
/**
 * kontainers_WP_theme template for displaying Archives
 *
 * @package WordPress
 * @subpackage kontainers_WP_theme
 * @since kontainers_WP_theme 1.0
 */

get_header(); ?>

<!--  This holds the WP page Content - k-blog-holder class for blog pages only -->
<div class="non-app k-blog-holder">

	<!--  Top bar with nav -->
	<?php include('top-nav.php') ?>

	<!--  form_holder - holds scrolling content -->
	<div class="form_holder">

		<!--  conent_holder - positions content -->
		<div class="content_holder">
			<section class="page-content primary" role="main">
				<article class="post">
					<?php //loop to get content
					if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
						<?php the_content(); ?>
					<?php endwhile; ?>
				</article>
			</section>
		</div>
		<!--/content_holder-->

	</div>
	<!--/form_holder-->

</div>
<?php get_footer(); ?>


